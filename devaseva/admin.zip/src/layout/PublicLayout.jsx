import { Outlet } from "react-router-dom";
const PublicLayout = () => {
  return <Outlet />;
};

export default PublicLayout;
