export const actionType = {
  website_link: "Website Link",
  vcard: "V Card",
  whatsapp_link: "WhatsApp Link",
};
