import React from 'react';

const HeroSection = () => {
  return (
    <section className="relative bg-gray-200  md:py-16 bg-cover bg-center py-[200px]" style={{backgroundImage:"url(/images/banner.png)"}}>
      <div className="md:container mx-auto flex flex-col-reverse lg:flex-row items-center justify-between mt-[67px]">
        {/* Left Text Section */}
        <div className="lg:w-2/3 text-center lg:text-left px-4 lg:px-8">
          {/* <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-yellow-900 leading-tight">
            Be a Real-Life Hero
          </h1>
          <p className="mt-4 text-lg md:text-xl text-gray-600">
            Make essential commodities accessible to every life in India.
          </p> */}
        </div>

        {/* Right Image Section */}
        <div className="lg:w-1/4 mb-8 lg:mb-0  flex justify-center lg:justify-end px-4 lg:px-8  rounded h-[20px]  md:h-[400px]">
          {/* <div className="relative">
            <img
              src="https://d2aq6dqxahe4ka.cloudfront.net/themes/neumorphism/images/impact_kart/impactkart_banner2.png" // Replace with your actual image URL
              alt="Kids"
              className="w-full lg:w-96 rounded-lg shadow-lg"
            />
            <div className="absolute -bottom-8 right-0 transform translate-x-6 w-32 h-32 bg-white rounded-full flex items-center justify-center">
              <img
                src="https://d2aq6dqxahe4ka.cloudfront.net/themes/neumorphism/images/impact_kart/impactkart_banner2.png" // Replace with your secondary image URL
                alt="Hearts"
                className="w-20 h-20"
              />
            </div>
          </div> */}
        </div>
      </div>

      {/* Bottom Section */}
      <div className="bg-yellow-100 py-6 md:py-10 mt-8  border-dashed rounded border-yellow-500 absolute w-[80%] md:w-[60%] -translate-x-1/2 left-1/2 -bottom-[66px] md:-bottom-[73px]">
        <div className="md:container mx-auto text-center">
          <h2 className="text-xl md:text-3xl font-bold text-yellow-800">
            Trustworthy & Transparent Donations
          </h2>
          <p className="mt-2 text-gray-600 text-xs md:text-normal">
          We keep you in the loop with regular updates and complete transparency on how your donation is used
          </p>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
