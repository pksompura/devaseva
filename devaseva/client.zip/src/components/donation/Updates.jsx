import React from 'react';

const Updates = () => {
  return (
    <section className="container mx-auto p-4 bg-white shadow-md rounded-md my-6">
      <h3 className="text-xl font-bold">Updates</h3>
      <p className="text-gray-600">Updates will be posted soon.</p>
    </section>
  );
};

export default Updates;
